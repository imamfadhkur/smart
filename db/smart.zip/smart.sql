/*==============================================================*/
/* DBMS name:      Sybase SQL Anywhere 12                       */
/* Created on:     19-Jul-21 18:21:06                           */
/*==============================================================*/

/*==============================================================*/
/* Table: ADMIN                                                 */
/*==============================================================*/
create table ADMIN 
(
   NOMOR_PEGAWAI        varchar(32)                    not null,
   PASSWORD             varchar(64)                    not null,
   NAMA_ADMIN           varchar(64)                    not null,
   ALAMAT               varchar(128)                   null,
   EMAIL_PEGAWAI        varchar(64)                    null,
   NO_TELP              varchar(32)                    null,
   constraint PK_ADMIN primary key (NOMOR_PEGAWAI)
);

/*==============================================================*/
/* Index: ADMIN_PK                                              */
/*==============================================================*/
create unique index ADMIN_PK on ADMIN (
NOMOR_PEGAWAI ASC
);

/*==============================================================*/
/* Table: ANTRIAN                                               */
/*==============================================================*/
create table ANTRIAN 
(
   NOMOR_ANTRIAN        integer                        not null,
   TGL                  date                           not null,
   ID_DETIL_ANTRIAN     integer                        null,
   NOMOR_PEGAWAI        varchar(32)                    not null,
   ID_PENYAKIT          integer                        null,
   ID_PASIEN            varchar(32)                    null,
   ID_DOKTER            integer                        null,
   WAKTU                time                           not null,
   constraint PK_ANTRIAN primary key (NOMOR_ANTRIAN, TGL)
);

/*==============================================================*/
/* Index: ANTRIAN_PK                                            */
/*==============================================================*/
create unique index ANTRIAN_PK on ANTRIAN (
NOMOR_ANTRIAN ASC,
TGL ASC
);

/*==============================================================*/
/* Index: MENGELOLA_FK                                          */
/*==============================================================*/
create index MENGELOLA_FK on ANTRIAN (
NOMOR_PEGAWAI ASC
);

/*==============================================================*/
/* Index: STATUS_FK                                             */
/*==============================================================*/
create index STATUS_FK on ANTRIAN (
ID_DETIL_ANTRIAN ASC
);

/*==============================================================*/
/* Index: MEMPUNYAI_FK                                          */
/*==============================================================*/
create index MEMPUNYAI_FK on ANTRIAN (
ID_PENYAKIT ASC,
ID_PASIEN ASC,
ID_DOKTER ASC
);

/*==============================================================*/
/* Table: DETIL_STATUS_ANTRIAN                                  */
/*==============================================================*/
create table DETIL_STATUS_ANTRIAN 
(
   ID_DETIL_ANTRIAN     integer                        not null,
   STATUS_ANTRIAN       smallint                       null,
   constraint PK_DETIL_STATUS_ANTRIAN primary key (ID_DETIL_ANTRIAN)
);

/*==============================================================*/
/* Index: DETIL_STATUS_ANTRIAN_PK                               */
/*==============================================================*/
create unique index DETIL_STATUS_ANTRIAN_PK on DETIL_STATUS_ANTRIAN (
ID_DETIL_ANTRIAN ASC
);

/*==============================================================*/
/* Table: DOKTER                                                */
/*==============================================================*/
create table DOKTER 
(
   ID_DOKTER            integer                        not null,
   ID_SPESIALIS         integer                        null,
   PASSWORD             varchar(64)                    null,
   NAMA_DOKTER          varchar(64)                    null,
   EMAIL_DOKTER         varchar(64)                    null,
   NO_TELP              varchar(32)                    null,
   constraint PK_DOKTER primary key (ID_DOKTER)
);

/*==============================================================*/
/* Index: DOKTER_PK                                             */
/*==============================================================*/
create unique index DOKTER_PK on DOKTER (
ID_DOKTER ASC
);

/*==============================================================*/
/* Index: BERKEAHLIAN_FK                                        */
/*==============================================================*/
create index BERKEAHLIAN_FK on DOKTER (
ID_SPESIALIS ASC
);

/*==============================================================*/
/* Table: PASIEN                                                */
/*==============================================================*/
create table PASIEN 
(
   ID_PASIEN            varchar(32)                    not null,
   NAMA_PASIEN          varchar(64)                    not null,
   PASSWORD             varchar(64)                    not null,
   NIK                  varchar(32)                    not null,
   ALAMAT               varchar(128)                   null,
   EMAIL_PASIEN         varchar(64)                    null,
   NO_TELP              varchar(32)                    null,
   constraint PK_PASIEN primary key (ID_PASIEN)
);

/*==============================================================*/
/* Index: PASIEN_PK                                             */
/*==============================================================*/
create unique index PASIEN_PK on PASIEN (
ID_PASIEN ASC
);

/*==============================================================*/
/* Table: SPESIALIS                                             */
/*==============================================================*/
create table SPESIALIS 
(
   ID_SPESIALIS         integer                        not null,
   SPESIALIS            varchar(64)                    not null,
   constraint PK_SPESIALIS primary key (ID_SPESIALIS)
);

/*==============================================================*/
/* Index: SPESIALIS_PK                                          */
/*==============================================================*/
create unique index SPESIALIS_PK on SPESIALIS (
ID_SPESIALIS ASC
);

/*==============================================================*/
/* Table: PENYAKIT                                              */
/*==============================================================*/
create table PENYAKIT 
(
   ID_PENYAKIT          integer                        not null,
   NAMA_PENYAKIT        varchar(64)                    null,
   constraint PK_PENYAKIT primary key (ID_PENYAKIT)
);

/*==============================================================*/
/* Index: PENYAKIT_PK                                           */
/*==============================================================*/
create unique index PENYAKIT_PK on PENYAKIT (
ID_PENYAKIT ASC
);

/*==============================================================*/
/* Table: PPD                                                   */
/*==============================================================*/
create table PPD 
(
   ID_PENYAKIT          integer                        not null,
   ID_PASIEN            varchar(32)                    not null,
   ID_DOKTER            integer                        not null,
   constraint PK_PPD primary key clustered (ID_PENYAKIT, ID_PASIEN, ID_DOKTER)
);

/*==============================================================*/
/* Index: PPD_PK                                                */
/*==============================================================*/
create unique index PPD_PK on PPD (
ID_PENYAKIT ASC,
ID_PASIEN ASC,
ID_DOKTER ASC
);

/*==============================================================*/
/* Index: DIMILIKI_FK                                           */
/*==============================================================*/
create index DIMILIKI_FK on PPD (
ID_PENYAKIT ASC
);

/*==============================================================*/
/* Index: MEMILIKI_FK                                           */
/*==============================================================*/
create index MEMILIKI_FK on PPD (
ID_PASIEN ASC
);

/*==============================================================*/
/* Index: MEMERIKSA_FK                                          */
/*==============================================================*/
create index MEMERIKSA_FK on PPD (
ID_DOKTER ASC
);


alter table ANTRIAN
   add constraint FK_ANTRIAN_MEMPUNYAI_PPD foreign key (ID_PENYAKIT, ID_PASIEN, ID_DOKTER)
      references PPD (ID_PENYAKIT, ID_PASIEN, ID_DOKTER)
      on update restrict
      on delete restrict;

alter table ANTRIAN
   add constraint FK_ANTRIAN_MENGELOLA_ADMIN foreign key (NOMOR_PEGAWAI)
      references ADMIN (NOMOR_PEGAWAI)
      on update restrict
      on delete restrict;

alter table ANTRIAN
   add constraint FK_ANTRIAN_STATUS_DETIL_ST foreign key (ID_DETIL_ANTRIAN)
      references DETIL_STATUS_ANTRIAN (ID_DETIL_ANTRIAN)
      on update restrict
      on delete restrict;

alter table DOKTER
   add constraint FK_DOKTER_BERKEAHLI_SPESIALI foreign key (ID_SPESIALIS)
      references SPESIALIS (ID_SPESIALIS)
      on update restrict
      on delete restrict;

alter table PPD
   add constraint FK_PPD_DIMILIKI_PENYAKIT foreign key (ID_PENYAKIT)
      references PENYAKIT (ID_PENYAKIT)
      on update restrict
      on delete restrict;

alter table PPD
   add constraint FK_PPD_MEMERIKSA_DOKTER foreign key (ID_DOKTER)
      references DOKTER (ID_DOKTER)
      on update restrict
      on delete restrict;

alter table PPD
   add constraint FK_PPD_MEMILIKI_PASIEN foreign key (ID_PASIEN)
      references PASIEN (ID_PASIEN)
      on update restrict
      on delete restrict;

